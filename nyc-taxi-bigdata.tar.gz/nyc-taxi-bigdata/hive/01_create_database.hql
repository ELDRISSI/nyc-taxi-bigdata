-- ============================================================
-- ETAPE 1 : Création de la base de données
-- Projet   : NYC Yellow Taxi Big Data
-- Auteur   : elidrissi
-- ============================================================

CREATE DATABASE IF NOT EXISTS taxi_project;

USE taxi_project;

SHOW DATABASES;
