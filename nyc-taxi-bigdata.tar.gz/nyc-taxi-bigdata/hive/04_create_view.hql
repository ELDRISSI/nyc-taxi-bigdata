-- ============================================================
-- ETAPE 4 : Création de la vue zone_summary
-- Projet   : NYC Yellow Taxi Big Data
-- Auteur   : elidrissi
-- ============================================================

USE taxi_project;

CREATE VIEW IF NOT EXISTS zone_summary AS
SELECT
    pickup_zone,
    COUNT(*)                        AS nb_trips,
    ROUND(AVG(trip_distance), 2)    AS avg_distance,
    ROUND(AVG(total_amount), 2)     AS avg_amount,
    ROUND(SUM(total_amount), 2)     AS total_revenue
FROM taxi_clean
GROUP BY pickup_zone;

-- Vérification
SELECT * FROM zone_summary ORDER BY nb_trips DESC LIMIT 10;
