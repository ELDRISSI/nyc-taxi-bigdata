-- ============================================================
-- ETAPE 5 : Création de la table zone_lookup
-- Projet   : NYC Yellow Taxi Big Data
-- Auteur   : elidrissi
-- Note     : colonnes dans l'ordre du fichier CSV importé
--            Borough, LocationID, service_zone, Zone
-- ============================================================

USE taxi_project;

DROP TABLE IF EXISTS zone_lookup;

CREATE EXTERNAL TABLE zone_lookup (
    Borough       STRING,
    LocationID    INT,
    service_zone  STRING,
    Zone          STRING
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION '/user/hdfs/zone_lookup'
TBLPROPERTIES ("skip.header.line.count"="1");

-- Vérification
SELECT LocationID, Zone, Borough FROM zone_lookup LIMIT 10;
