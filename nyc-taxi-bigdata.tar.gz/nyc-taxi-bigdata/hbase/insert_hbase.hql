-- ============================================================
-- PARTIE 11 : Remplir HBase depuis taxi_clean
-- Projet    : NYC Yellow Taxi Big Data
-- Auteur    : elidrissi
-- Prérequis : hive_hbase_link.hql exécuté avec succès
-- ============================================================

USE taxi_project;

INSERT OVERWRITE TABLE hbase_zone_stats
SELECT
    CAST(t.pickup_zone AS STRING)          AS zone_id,

    COUNT(*)                               AS nb_trajets,

    ROUND(AVG(t.trip_distance), 2)         AS distance_moyenne,

    ROUND(AVG(t.total_amount), 2)          AS montant_moyen,

    -- Top destination : zone de dropoff la plus fréquente
    (
        SELECT CAST(d.dropoff_zone AS STRING)
        FROM taxi_clean d
        WHERE d.pickup_zone = t.pickup_zone
        GROUP BY d.dropoff_zone
        ORDER BY COUNT(*) DESC
        LIMIT 1
    ) AS top_destinations,

    -- Heure de pointe : heure avec le plus de départs
    (
        SELECT h.pickup_hour
        FROM taxi_clean h
        WHERE h.pickup_zone = t.pickup_zone
        GROUP BY h.pickup_hour
        ORDER BY COUNT(*) DESC
        LIMIT 1
    ) AS heure_pointe

FROM taxi_clean t
GROUP BY t.pickup_zone;

-- Vérification depuis Hive
SELECT * FROM hbase_zone_stats ORDER BY nb_trajets DESC LIMIT 10;
