#!/bin/bash
# ============================================================
# Import : taxi_zone_lookup  MySQL → HDFS
# Projet : NYC Yellow Taxi Big Data
# Auteur : elidrissi
# ============================================================

sqoop import \
  --connect jdbc:mysql://localhost:3306/NYC_TAXIS \
  --username elidrissi \
  -P \
  --table taxi_zone_lookup \
  --target-dir /user/hdfs/zone_lookup \
  --fields-terminated-by ',' \
  --null-string '\\N' \
  --null-non-string '\\N' \
  --num-mappers 1 \
  --delete-target-dir

# Vérification
echo "=== Vérification import ==="
hdfs dfs -ls /user/hdfs/zone_lookup
hdfs dfs -cat /user/hdfs/zone_lookup/part-m-00000 | head -5
