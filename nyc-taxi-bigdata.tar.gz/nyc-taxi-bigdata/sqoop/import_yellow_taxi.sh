#!/bin/bash
# ============================================================
# Import : yellow_taxi_trips  MySQL → HDFS
# Projet : NYC Yellow Taxi Big Data
# Auteur : elidrissi
# ============================================================

sqoop import \
  --connect jdbc:mysql://localhost:3306/NYC_TAXIS \
  --username elidrissi \
  -P \
  --table yellow_taxi_trips \
  --target-dir /user/hdfs/yellow_taxi_trips \
  --fields-terminated-by ',' \
  --null-string '\\N' \
  --null-non-string '\\N' \
  --num-mappers 1 \
  --delete-target-dir

# Vérification
echo "=== Vérification import ==="
hdfs dfs -ls /user/hdfs/yellow_taxi_trips
hdfs dfs -cat /user/hdfs/yellow_taxi_trips/part-m-00000 | wc -l
